export const baseUrl =`https://patnam-trends-botique.herokuapp.com/api` ;
export const registerUrl= `${baseUrl}/register`;
export const loginUrl=`${baseUrl}/login`;
export const Url=`${baseUrl}/myuser`
export const updateProfileUrl=`${baseUrl}/edituser/62bc8d3772dc0fb1afc17cbe`


export const ACCESS_TOKEN = () => sessionStorage.getItem('access_token');
