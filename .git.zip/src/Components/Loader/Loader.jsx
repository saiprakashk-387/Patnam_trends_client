import React from 'react';
import './Loader.css'

const Loader = () => {
  return (
    <div class="loader"></div>
  )
}

export default Loader
